# Release 1.1.0.72

本目录包含标书智能体 **v1.1.0.72** 发布物。

## 下载清单

| 文件 | 说明 |
|------|------|
| `TenderAgentSetup-v1.1.0.72.exe` | Windows 离线安装包（在 Windows 上运行 `package-desktop.ps1` 生成后复制至此） |
| `tender-agent-manual-v1.1.0.72.md` | 用户手册 |
| `tender-agent-release-v1.1.0.72.zip` | 手册 + 验收脚本 + 版本信息压缩包 |
| `tender-agent-test-materials-v1.1.0.72.zip` | 系统验收与功能测试用完整材料包 |
| `VERSION.json` | 版本元数据 |

## Windows 打包命令

```powershell
.\package-desktop.ps1 -AppVersion "1.1.0.72"
```

打包完成后安装包会复制到本目录。

## 验收

```powershell
.\scripts\verify_windows_features.ps1
```

